function [result] = sjxx(data,n,r,p)
    result=0;
    J=ones(r,r);
    for i=1:p
        M=data{i};
        M=M(:,1:r);
        M=M-ones(n,1)*mean(M);
        for j=1:n
            result=result+M(j,:)*J*M(j,:)';
        end
    end
end

