n = 5;
r = 6;
p = 2;
rawdata = xlsread('qtcdata.xlsx');
data{1} = rawdata(1:5,:);
data{2} = rawdata(6:10,:);

X1 = data{1}(:, 1:r);       Y1 = data{1}(:, (r+1):2*r);
X2 = data{2}(:, 1:r);       Y2 = data{2}(:, (r+1):2*r);
X1_bar = mean(X1, 2);           Y1_bar = mean(Y1, 2);
X1_vec = reshape(X1, n*r, 1);   Y1_vec = reshape(Y1, n*r, 1);
X1bar_vec = repmat(X1_bar, r, 1);  Y1bar_vec = repmat(Y1_bar, r, 1);
X2_bar = mean(X2, 2);           Y2_bar = mean(Y2, 2);
X2_vec = reshape(X2, n*r, 1);   Y2_vec = reshape(Y2, n*r, 1);
X2bar_vec = repmat(X2_bar, r, 1);  Y2bar_vec = repmat(Y2_bar, r, 1);

dpi_naive = (( mean(Y2,1) - mean(X2,1)) - ( mean(Y1,1) - mean(X1,1)))';

dummy = [repmat( [ones(1, n), zeros(1, n*r)], 1, r - 1), ones(1, n)];
dummy = reshape( dummy, n*r, r );
Ttd0 = fitlm([ [dummy;zeros(n*r, r)],...
                [zeros(n*r, r);dummy], [X1_vec; X2_vec], [X1bar_vec; X2bar_vec] ],...
                [Y1_vec-X1_vec;Y2_vec-X2_vec], 'Intercept', false);
dpi_Ttd = table2array( Ttd0.Coefficients(1+r:2*r,1) ) -...
                table2array(Ttd0.Coefficients(1:r, 1));
resid = reshape(table2array(Ttd0.Residuals(:,1)), n, r*2);
            resid = [resid(:,1:r);resid(:,(r+1):(2*r))];
Omega_h_ = resid'*resid/(2*n-1);
sigma_diag_ = mean(diag(Omega_h_));
sigma_rho_ = sum(sum(Omega_h_-diag(diag(Omega_h_))))/(r*(r-1));
[pval_qtc, pval_t1_qtc, pval_t2_qtc, pval_large_qtc, pval_large_t1_qtc, pval_large_t2_qtc] = ...
    hypothesis(dpi_Ttd', sigma_rho_, sigma_diag_, 0, n );
pvalue(1) = pval_qtc;
pvaluec(1) = pval_t1_qtc;

[sigma,rho_1,rho_2,rho_3]=MLE(data,n,r,p);
pi=MLE_pi(data,n,r,p,sigma,rho_1,rho_2,rho_3);
dpi_MLE=pi(:,2)-pi(:,1);
Sigma1_h = (1 - rho_1)*eye(r) + rho_1*ones(r);
Sigma12_h = (rho_2 - rho_3)*eye(r) + rho_3*ones(r);
Omega_h = Sigma1_h - Sigma12_h' / Sigma1_h * Sigma12_h;
sigma_rho = sigma * Omega_h(1,2);
sigma_diag = sigma * Omega_h(1,1);
[pval_qtc, pval_t1_qtc, pval_t2_qtc, pval_large_qtc, pval_large_t1_qtc, pval_large_t2_qtc] = ...
    hypothesis(dpi_MLE', sigma_rho, sigma_diag, 0, n );
pvalue(2) = pval_qtc;
pvaluec(2) = pval_t1_qtc;

[sigma,rho_1,rho_2,rho_3]=OLS(data,n,r,p);
alpha_h = (rho_2 - rho_3)/(1 - rho_1);
beta_h = r*(rho_3 - rho_1*rho_2)/( (1-rho_1)*(1+(r-1)*rho_1) );
dpi_Onestep = mean( (Y2 - alpha_h*X2 - beta_h*reshape(repmat(mean(X2,2),1,r),n,r))-...
                (Y1 - alpha_h*X1 - beta_h*reshape(repmat(mean(X1,2),1,r),n,r)), 1)';
Sigma1_h = (1 - rho_1)*eye(r) + rho_1*ones(r);
Sigma12_h = (rho_2 - rho_3)*eye(r) + rho_3*ones(r);
Omega_h = Sigma1_h - Sigma12_h' / Sigma1_h * Sigma12_h;
sigma_rho = sigma * Omega_h(1,2);
sigma_diag = sigma * Omega_h(1,1);
[pval_qtc, pval_t1_qtc, pval_t2_qtc, pval_large_qtc, pval_large_t1_qtc, pval_large_t2_qtc] = ...
    hypothesis(dpi_MLE', sigma_rho, sigma_diag, 0, n );
pvalue(3) = pval_qtc;
pvaluec(3) = pval_t1_qtc;
[pval_qtc, pval_t1_qtc, pval_t2_qtc, pval_large_qtc, pval_large_t1_qtc, pval_large_t2_qtc] = ...
    hypothesis(dpi_Onestep', sigma_rho, sigma_diag, 0, n );
pvalue(4) = pval_qtc;
pvaluec(4) = pval_t1_qtc;

result_qtc = [dpi_naive, dpi_Ttd, dpi_MLE, dpi_Onestep]
[pvalue; pvaluec]





n = 5;
r = 6;
p = 2;
rawdata = xlsread('jtcdata.xlsx');
data{1} = rawdata(1:5,:);
data{2} = rawdata(6:10,:);

X1 = data{1}(:, 1:r);       Y1 = data{1}(:, (r+1):2*r);
X2 = data{2}(:, 1:r);       Y2 = data{2}(:, (r+1):2*r);
X1_bar = mean(X1, 2);           Y1_bar = mean(Y1, 2);
X1_vec = reshape(X1, n*r, 1);   Y1_vec = reshape(Y1, n*r, 1);
X1bar_vec = repmat(X1_bar, r, 1);  Y1bar_vec = repmat(Y1_bar, r, 1);
X2_bar = mean(X2, 2);           Y2_bar = mean(Y2, 2);
X2_vec = reshape(X2, n*r, 1);   Y2_vec = reshape(Y2, n*r, 1);
X2bar_vec = repmat(X2_bar, r, 1);  Y2bar_vec = repmat(Y2_bar, r, 1);

dpi_naive = (( mean(Y2,1) - mean(X2,1)) - ( mean(Y1,1) - mean(X1,1)))';

dummy = [repmat( [ones(1, n), zeros(1, n*r)], 1, r - 1), ones(1, n)];
dummy = reshape( dummy, n*r, r );
Ttd0 = fitlm([ [dummy;zeros(n*r, r)],...
                [zeros(n*r, r);dummy], [X1_vec; X2_vec], [X1bar_vec; X2bar_vec] ],...
                [Y1_vec-X1_vec;Y2_vec-X2_vec], 'Intercept', false);
dpi_Ttd = table2array( Ttd0.Coefficients(1+r:2*r,1) ) -...
                table2array(Ttd0.Coefficients(1:r, 1));
resid = reshape(table2array(Ttd0.Residuals(:,1)), n, r*2);
            resid = [resid(:,1:r);resid(:,(r+1):(2*r))];
Omega_h_ = resid'*resid/(2*n-1);
sigma_diag_ = mean(diag(Omega_h_));
sigma_rho_ = sum(sum(Omega_h_-diag(diag(Omega_h_))))/(r*(r-1));
[pval_jtc, pval_t1_jtc, pval_t2_jtc, pval_large_jtc, pval_large_t1_jtc, pval_large_t2_jtc] = ...
    hypothesis(dpi_Ttd', sigma_rho_, sigma_diag_, 0, n );
pvalue(1) = pval_jtc;
pvaluec(1) = pval_t1_jtc;

[sigma,rho_1,rho_2,rho_3]=MLE(data,n,r,p);
pi=MLE_pi(data,n,r,p,sigma,rho_1,rho_2,rho_3);
dpi_MLE=pi(:,2)-pi(:,1);
Sigma1_h = (1 - rho_1)*eye(r) + rho_1*ones(r);
Sigma12_h = (rho_2 - rho_3)*eye(r) + rho_3*ones(r);
Omega_h = Sigma1_h - Sigma12_h' / Sigma1_h * Sigma12_h;
sigma_rho = sigma * Omega_h(1,2);
sigma_diag = sigma * Omega_h(1,1);
[pval_jtc, pval_t1_jtc, pval_t2_jtc, pval_large_jtc, pval_large_t1_jtc, pval_large_t2_jtc] = ...
    hypothesis(dpi_MLE', sigma_rho, sigma_diag, 0, n );
pvalue(2) = pval_jtc;
pvaluec(2) = pval_t1_jtc;

[sigma,rho_1,rho_2,rho_3]=OLS(data,n,r,p);
alpha_h = (rho_2 - rho_3)/(1 - rho_1);
beta_h = r*(rho_3 - rho_1*rho_2)/( (1-rho_1)*(1+(r-1)*rho_1) );
dpi_Onestep = mean( (Y2 - alpha_h*X2 - beta_h*reshape(repmat(mean(X2,2),1,r),n,r))-...
                (Y1 - alpha_h*X1 - beta_h*reshape(repmat(mean(X1,2),1,r),n,r)), 1)';
Sigma1_h = (1 - rho_1)*eye(r) + rho_1*ones(r);
Sigma12_h = (rho_2 - rho_3)*eye(r) + rho_3*ones(r);
Omega_h = Sigma1_h - Sigma12_h' / Sigma1_h * Sigma12_h;
sigma_rho = sigma * Omega_h(1,2);
sigma_diag = sigma * Omega_h(1,1);
[pval_qtc, pval_t1_jtc, pval_t2_jtc, pval_large_jtc, pval_large_t1_jtc, pval_large_t2_jtc] = ...
    hypothesis(dpi_MLE', sigma_rho, sigma_diag, 0, n );
pvalue(3) = pval_jtc;
pvaluec(3) = pval_t1_jtc;
[pval_qtc, pval_t1_jtc, pval_t2_jtc, pval_large_jtc, pval_large_t1_jtc, pval_large_t2_jtc] = ...
    hypothesis(dpi_Onestep', sigma_rho, sigma_diag, 0, n );
pvalue(4) = pval_jtc;
pvaluec(4) = pval_t1_jtc;

result_jtc = [dpi_naive, dpi_Ttd, dpi_MLE, dpi_Onestep]
[pvalue; pvaluec]



result = [result_qtc'; result_jtc'];
writematrix(result, 'estimateandp.xls');


