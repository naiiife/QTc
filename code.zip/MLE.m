function [sigma,rho_1,rho_2,rho_3] = MLE(data,n,r,p)
    Si=si(data,n,r,p);
    Sixx=sixx(data,n,r,p);
    Sixy=sixy(data,n,r,p);
    Siyy=siyy(data,n,r,p);
    Sj=sj(data,n,r,p);
    Sjxx=sjxx(data,n,r,p);
    Sjxy=sjxy(data,n,r,p);
    Sjyy=sjyy(data,n,r,p);
    t=Newton(-Sj/(2*Sjxy),-(Sjxx+Sjyy-Sj)/(2*Sjxy),1);
    lambda_1=(t*(Sjxx+Sjyy)-(1+t^2)*Sjxy)/(n*p*r*t*(1-t^2));
    lambda_3=lambda_1*t;
    t=Newton((r*Si-Sj)/(2*(r*Sixy-Sjxy)),(r*Sixx+r*Siyy-Sjxx-Sjyy-(r*Si-Sj))/(2*(r*Sixy-Sjxy)),-1);
    lambda_2=(t*(r*Sixx+r*Siyy-Sjxx-Sjyy)-(1+t^2)*(r*Sixy-Sjxy))/(n*p*r*(r-1)*t*(1-t^2));
    lambda_4=lambda_2*t;
    sigma=(lambda_1+(r-1)*lambda_2)/r;
    rho_1=1-lambda_2/sigma;
    rho_2=(lambda_3+(r-1)*lambda_4)/(r*sigma);
    rho_3=rho_2-lambda_4/sigma;
end

