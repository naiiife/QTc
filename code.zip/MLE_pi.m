function Pi = MLE_pi(data,n,r,p,sigma,rho_1,rho_2,rho_3)
    lambda_1=sigma*(1+(r-1)*rho_1);
    lambda_2=sigma*(1-rho_1);
    lambda_3=sigma*(rho_2+(r-1)*rho_3);
    lambda_4=sigma*(rho_2-rho_3);
    mu=MLE_mu(data,n,r,p)';
    Pi=zeros(r,p);
    P=(lambda_4/lambda_2)*eye(r)+(lambda_3/lambda_1-lambda_4/lambda_2)/r*ones(r,r);
    for i=1:p
        A=data{i};
        x=(mean(A(:,1:r)))'-mu;
        y=P*x;
        Pi(:,i)=(mean(A(:,(r+1):2*r)))'-mu-y;
    end
end

