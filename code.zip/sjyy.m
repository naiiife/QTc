function [result] = sjyy(data,n,r,p)
    result=0;
    J=ones(r,r);
    for i=1:p
        M=data{i};
        M=M(:,r+1:2*r);
        M=M-ones(n,1)*mean(M);
        for j=1:n
            result=result+M(j,:)*J*M(j,:)';
        end
    end
end