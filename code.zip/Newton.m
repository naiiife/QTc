function [x] = Newton(a,b,c)
    p=b/a;
    q=c/a;
    x=nthroot(-q/2+sqrt(p^3/27+q^2/4),3)+nthroot(-q/2-sqrt(p^3/27+q^2/4),3);
end
