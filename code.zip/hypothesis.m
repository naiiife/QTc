function [pval, pval_t1, pval_t2, pval_large, pval_large_t1, pval_large_t2] = hypothesis(W, sigma_rho, sigma_diag, theta, n )

    if sigma_rho<0
        sigma_rho = 0;
    end
    r = length(W);
    [T, k0] = max(W);
    ak0 = (W-T)*sqrt(n/sigma_rho)/2;
    ak0(k0) = [];
    rho_ = sigma_rho/sigma_diag;
    Rk0 = rho_*ones(r-1) + (1-rho_)*eye(r-1);
    pval_large = normcdf( sqrt(n/(2*sigma_diag))*(T-theta) );
    pval_large_t2 = tcdf( sqrt(n/(2*sigma_diag))*(T-theta), (2*n-2) );
    pval_large_t1 = tcdf( sqrt(n/(2*sigma_diag))*(T-theta), (r-1)*(2*n-2) );
    
    R = rho_*ones(r) + (1-rho_)*eye(r);
    a = (W-T).*sqrt(n/sigma_rho)/2;
    a(k0) = -inf;
    m1 = 1 - mvncdf(ak0,[],Rk0);
    ET = theta * m1;
    tot = 0;
    simunum = 4000*r;
    for simu=1:simunum
        z = mvnrnd(zeros(1,r),R,1);
        tot = tot + z(k0)^2*all(z-a>0);
    end
    v1 = tot/simunum;
    VarT = theta*theta*m1*(1-m1) + 2*sigma_diag*v1/n;
    pval = normcdf( (T-ET)/sqrt(VarT) );
    pval_t2 = tcdf( (T-ET)/sqrt(VarT), (2*n-2) );
    pval_t1 = tcdf( (T-ET)/sqrt(VarT), (r-1)*(2*n-2) );
    
end