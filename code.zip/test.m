n=[5,5,5,20,20,20,50,50,50];
r=[4,8,12,4,8,12,4,8,12];
p=2;
Sigma=400;
Rho_1=[0.75,0.80,0.85,0.85,0.90,0.90];
Rho_2=[0.85,0.85,0.85,0.85,0.85,0.85];
Rho_3=[0.70,0.80,0.80,0.85,0.85,0.80];
iteration0=10000;
j=5;
theta=10;
POWER_z=zeros(1,27);
POWER_adj=zeros(1,27);
POWER_t1=zeros(1,27);
POWER_t2=zeros(1,27);
POWER_adjt1=zeros(1,27);
POWER_adjt2=zeros(1,27);

for k=1:3
for i=1:9
    Mu=200*ones(r(i),1);
    if k==1
        Pi=[zeros(r(i),1),10*ones(r(i),1)];
    elseif k==2
        Pi=[zeros(r(i),1),[10;-100*ones(r(i)-1,1)]];
    else
        Pi=[zeros(r(i),1),zeros(r(i),1)];
    end
    
    Rej_z=0;
    Rej_adj=0;
    Rej_t1=0;
    Rej_t2=0;
    Rej_adjt1=0;
    Rej_adjt2=0;
    iteration=iteration0;
    for iter=1:iteration0
        Rho1=Rho_1(j);
        Rho2=Rho_2(j);
        Rho3=Rho_3(j);
        data=generate(n(i),r(i),p,Mu,Pi,Sigma,Rho1,Rho2,Rho3);
        try
            [sigma,rho_1,rho_2,rho_3]=MLE(data,n(i),r(i),p);
        catch
            [sigma,rho_1,rho_2,rho_3]=OLS(data,n(i),r(i),p);
        end
        try
            pi=MLE_pi(data,n(i),r(i),p,sigma,rho_1,rho_2,rho_3);
        catch
            alpha_h = (rho_2 - rho_3)/(1 - rho_1);
            beta_h = r(i)*(rho_3 - rho_1*rho_2)/( (1-rho_1)*(1+(r(i)-1)*rho_1) );
            pi = mean( (Y2 - alpha_h*X2 - beta_h*reshape( repmat(mean(X2, 2), 1, r(i) ), n(i), r(i) ))-...
                (Y1 - alpha_h*X1 - beta_h*reshape( repmat(mean(X1, 2), 1, r(i) ), n(i), r(i) )), 1);
        end
        dpi=pi(:,2)-pi(:,1);
        [sigma,rho_1,rho_2,rho_3]=OLS(data,n(i),r(i),p);
        Sigma1_h = (1 - rho_1)*eye(r(i)) + rho_1*ones(r(i));
        Sigma12_h = (rho_2 - rho_3)*eye(r(i)) + rho_3*ones(r(i));
        Omega_h = Sigma1_h - Sigma12_h' / Sigma1_h * Sigma12_h;
        sigma_rho = sigma * Omega_h(1,2);
        sigma_diag = sigma * Omega_h(1,1);
        try
            [pval, pval_t1, pval_t2, pval_large, pval_large_t1, pval_large_t2] = hypothesis(dpi', sigma_rho, sigma_diag, theta, n(i) );
            if pval_large<0.05
                Rej_z = Rej_z + 1;
            end
            if pval<0.05
                Rej_adj = Rej_adj + 1;
            end
            if pval_large_t1<0.05
                Rej_t1 = Rej_t1 + 1;
            end
            if pval_large_t2<0.05
                Rej_t2 = Rej_t2 + 1;
            end
            if pval_t1<0.05
                Rej_adjt1 = Rej_adjt1 + 1;
            end
            if pval_t2<0.05
                Rej_adjt2 = Rej_adjt2 + 1;
            end
        catch
            iteration = iteration - 1;
        end
 
    end
    POWER_z(9*(k-1)+i) = Rej_z / iteration;
    POWER_adj(9*(k-1)+i) = Rej_adj / iteration;
    POWER_t1(9*(k-1)+i) = Rej_t1 / iteration;
    POWER_t2(9*(k-1)+i) = Rej_t2 / iteration;
    POWER_adjt1(9*(k-1)+i) = Rej_adjt1 / iteration;
    POWER_adjt2(9*(k-1)+i) = Rej_adjt2 / iteration;
    res_all = [POWER_z;POWER_t1;POWER_t2;POWER_adj;POWER_adjt1;POWER_adjt2]';
    res_re = [res_all(1:9,:),res_all(10:18,:),res_all(19:27,:)];
    result = [n', r' , res_re]
    writematrix(result, 'power.txt');
    writematrix(result, 'power.xls');
    end
end
