n=[5,5,5,10,10,10,15,15,15];
r=[4,8,12,4,8,12,4,8,12];
p=2;
Sigma=400;
Rho_1=[0.75,0.80,0.85,0.85,0.90,0.90];
Rho_2=[0.85,0.85,0.85,0.85,0.85,0.85];
Rho_3=[0.70,0.80,0.80,0.85,0.85,0.80];
iteration0=10000;
j=5;
theta=10;
POWER_MLE=zeros(1,27);
POWER_OLS=zeros(1,27);
POWER_Ttd=zeros(1,27);
POWER_MLEt=zeros(1,27);
POWER_OLSt=zeros(1,27);
POWER_Ttdt=zeros(1,27);
POWER_MLEO=zeros(1,27);
POWER_MLEOt=zeros(1,27);

for k=1:3
for i=1:9
    Mu=200*ones(r(i),1);
    if k==1
        Pi=[zeros(r(i),1),10*ones(r(i),1)];
    elseif k==2
        Pi=[zeros(r(i),1),[10;-100*ones(r(i)-1,1)]];
    else
        Pi=[zeros(r(i),1),zeros(r(i),1)];
    end
    
    Rej_MLE=0;
    Rej_MLEt=0;
    Rej_MLEO=0;
    Rej_MLEOt=0;
    Rej_OLS=0;
    Rej_OLSt=0;
    Rej_Ttd=0;
    Rej_Ttdt=0;
    iteration=iteration0;
    for iter=1:iteration0
        rand('seed',iter)
        Rho1=Rho_1(j);
        Rho2=Rho_2(j);
        Rho3=Rho_3(j);
        data=generate(n(i),r(i),p,Mu,Pi,Sigma,Rho1,Rho2,Rho3);
        X1 = data{1}(:, 1:r(i));       Y1 = data{1}(:, (r(i)+1):2*r(i));
        X2 = data{2}(:, 1:r(i));       Y2 = data{2}(:, (r(i)+1):2*r(i));
        try
            [sigma_mle,rho_1mle,rho_2mle,rho_3mle]=MLE(data,n(i),r(i),p);
        catch
            [sigma_mle,rho_1mle,rho_2mle,rho_3mle]=OLS(data,n(i),r(i),p);
        end
        try
            pi_MLE = MLE_pi(data,n(i),r(i),p,sigma_mle,rho_1mle,rho_2mle,rho_3mle);
            dpi_MLE = pi_MLE(:,2) - pi_MLE(:,1);
            alpha_hmle = (rho_2mle - rho_3mle)/(1 - rho_1mle);
            beta_hmle = r(i)*(rho_3mle - rho_1mle*rho_2mle)/( (1-rho_1mle)*(1+(r(i)-1)*rho_1mle) );
            [sigma_ols,rho_1ols,rho_2ols,rho_3ols]=OLS(data,n(i),r(i),p);
            alpha_hols = (rho_2ols - rho_3ols)/(1 - rho_1ols);
            beta_hols = r(i)*(rho_3ols - rho_1ols*rho_2ols)/( (1-rho_1ols)*(1+(r(i)-1)*rho_1ols) );
            dpi_OLS = mean( (Y2 - alpha_hols*X2 - beta_h*reshape( repmat(mean(X2, 2), 1, r(i) ), n(i), r(i) ))-...
                (Y1 - alpha_hols*X1 - beta_h*reshape( repmat(mean(X1, 2), 1, r(i) ), n(i), r(i) )), 1)';
        catch
            [sigma_ols,rho_1ols,rho_2ols,rho_3ols]=OLS(data,n(i),r(i),p);
            alpha_hols = (rho_2ols - rho_3ols)/(1 - rho_1ols);
            beta_hols = r(i)*(rho_3ols - rho_1ols*rho_2ols)/( (1-rho_1ols)*(1+(r(i)-1)*rho_1ols) );
            dpi_OLS = mean( (Y2 - alpha_hols*X2 - beta_hols*reshape( repmat(mean(X2, 2), 1, r(i) ), n(i), r(i) ))-...
                (Y1 - alpha_hols*X1 - beta_hols*reshape( repmat(mean(X1, 2), 1, r(i) ), n(i), r(i) )), 1)';
            dpi_MLE = dpi_OLS;
        end
        Sigma1_hmle = (1 - rho_1mle)*eye(r(i)) + rho_1mle*ones(r(i));
        Sigma12_hmle = (rho_2mle - rho_3ols)*eye(r(i)) + rho_3mle*ones(r(i));
        Omega_hmle = Sigma1_hmle - Sigma12_hmle' / Sigma1_hmle * Sigma12_hmle;
        sigma_rho_mle = sigma_mle * Omega_hmle(1,2);
        sigma_diag_mle = sigma_mle * Omega_hmle(1,1);
        Sigma1_hols = (1 - rho_1ols)*eye(r(i)) + rho_1ols*ones(r(i));
        Sigma12_hols = (rho_2ols - rho_3ols)*eye(r(i)) + rho_3ols*ones(r(i));
        Omega_hols = Sigma1_hols - Sigma12_hols' / Sigma1_hols * Sigma12_hols;
        sigma_rho_ols = sigma_ols * Omega_hols(1,2);
        sigma_diag_ols = sigma_ols * Omega_hols(1,1);
        try
            [pval, pval_t1, pval_t2, pval_large, pval_large_t1, pval_large_t2] = ...
                hypothesis(dpi_MLE', sigma_rho_mle, sigma_diag_mle, theta, n(i) );
            if pval<0.05
                Rej_MLE = Rej_MLE + 1;
            end
            if pval_t1<0.05
                Rej_MLEt = Rej_MLEt + 1;
            end
            
            [pval, pval_t1, pval_t2, pval_large, pval_large_t1, pval_large_t2] = ...
                hypothesis(dpi_MLE', sigma_rho_ols, sigma_diag_ols, theta, n(i) );
            if pval<0.05
                Rej_MLEO = Rej_MLEO + 1;
            end
            if pval_t1<0.05
                Rej_MLEOt = Rej_MLEOt + 1;
            end
            
            [pval, pval_t1, pval_t2, pval_large, pval_large_t1, pval_large_t2] = ...
                hypothesis(dpi_OLS', sigma_rho_ols, sigma_diag_ols, theta, n(i) );
            if pval<0.05
                Rej_OLS = Rej_OLS + 1;
            end
            if pval_t1<0.05
                Rej_OLSt = Rej_OLSt + 1;
            end
            
            X1_bar = mean(X1, 2);           Y1_bar = mean(Y1, 2);
            X1_vec = reshape(X1, n(i)*r(i), 1);   Y1_vec = reshape(Y1, n(i)*r(i), 1);
            X1bar_vec = repmat(X1_bar, r(i), 1);  Y1bar_vec = repmat(Y1_bar, r(i), 1);
            X2_bar = mean(X2, 2);           Y2_bar = mean(Y2, 2);
            X2_vec = reshape(X2, n(i)*r(i), 1);   Y2_vec = reshape(Y2, n(i)*r(i), 1);
            X2bar_vec = repmat(X2_bar, r(i), 1);  Y2bar_vec = repmat(Y2_bar, r(i), 1);
            dummy = [repmat( [ones(1, n(i)), zeros(1, n(i)*r(i))], 1, r(i)-1), ones(1, n(i))];
            dummy = reshape( dummy, n(i)*r(i), r(i) );
            Ttd0 = fitlm([ [dummy;zeros(n(i)*r(i), r(i))],...
                [zeros(n(i)*r(i), r(i));dummy], [X1_vec; X2_vec], [X1bar_vec; X2bar_vec] ],...
                [Y1_vec-X1_vec;Y2_vec-X2_vec], 'Intercept', false);
            dpi_Ttd = table2array( Ttd0.Coefficients((1+r(i)):(2*r(i)),1) ) -...
                table2array(Ttd0.Coefficients(1:r(i), 1));
            resid = reshape(table2array(Ttd0.Residuals(:,1)), n(i), r(i)*2);
            resid = [resid(:,1:r(i));resid(:,(r(i)+1):(2*r(i)))];
            Omega_h_ = resid'*resid/(2*n(i)-1);
            sigma_diag_ = mean(diag(Omega_h_));
            sigma_rho_ = sum(sum(Omega_h_-diag(diag(Omega_h_))))/(r(i)*(r(i)-1));
            [pval, pval_t1, pval_t2, pval_large, pval_large_t1, pval_large_t2] = hypothesis(dpi_Ttd', sigma_rho_, sigma_diag_, theta, n(i) );
            if pval<0.05
                Rej_Ttd = Rej_Ttd + 1;
            end
            if pval_t1<0.05
                Rej_Ttdt = Rej_Ttdt + 1;
            end
        catch
            iteration = iteration - 1;
        end
        
    end
    iteration
    POWER_MLE(9*(k-1)+i) = Rej_MLE / iteration;
    POWER_MLEt(9*(k-1)+i) = Rej_MLEt / iteration;
    POWER_MLEO(9*(k-1)+i) = Rej_MLEO / iteration;
    POWER_MLEOt(9*(k-1)+i) = Rej_MLEOt / iteration;
    POWER_OLS(9*(k-1)+i) = Rej_OLS / iteration;
    POWER_OLSt(9*(k-1)+i) = Rej_OLSt / iteration;
    POWER_Ttd(9*(k-1)+i) = Rej_Ttd / iteration;
    POWER_Ttdt(9*(k-1)+i) = Rej_Ttdt / iteration;
    res_all = [POWER_MLE;POWER_MLEt;POWER_MLEO;POWER_MLEOt;POWER_OLS;POWER_OLSt;POWER_Ttd;POWER_Ttdt]';
    res_re = [res_all(1:9,:),res_all(10:18,:),res_all(19:27,:)];
    result = [n', r' , res_re]
    %writematrix(result, 'powercomp.txt');
    %writematrix(result, 'powercomp.xls');
    writetable(result, 'powercomp.txt');
    writetable(result, 'powercomp.xls');
    end
end
