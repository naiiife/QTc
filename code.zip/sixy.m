function [result] = sixy(data,n,r,p)
    result=0;
    for i=1:p
        M=data{i};
        M=M-ones(n,1)*mean(M);
        for j=1:n
            result=result+dot(M(j,1:r),M(j,r+1:2*r));
        end
    end
end
