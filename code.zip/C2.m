size_ = 5;                     r = 10;
mu = repmat(200, 1, r);         pi_ = repmat(10, 1, r);

it = 1;

naive = zeros(it, r);          BLUE = zeros(it, r);
Init = zeros(it, r);           Ttd = zeros(it, r);
GMM1 = zeros(it, r);           GMM2 = zeros(it, r);

for w = 1:it
    rand('seed', 100 + w);
    rho1 = 0.85;    rho2 = 0.85;    rho3 = 0.80;
    sigma2 = 400;
    disp( ['line 14: ', num2str( int8(1 - rho1 > abs(rho2 - rho3) ) )] )
    disp( ['line 14: ', num2str( int8(1 + (r-1)*rho1 > rho2 + (r-1)*rho3 ) ) ] )
    
    I = eye(r);    J = ones(r);
    Sigma1 = (1 - rho1)*I + rho1 * J;
    Sigma12 = (rho2 - rho3)*I + rho3 * J;
    Sigma = [ [Sigma1, Sigma12]; [Sigma12', Sigma1] ];
    
    Omega = Sigma1 - Sigma12' / Sigma1 * Sigma12;
    muXY = [mu, mu + pi_];
    XY1 = mvnrnd([mu+pi_, mu]', sigma2*Sigma, size_);
    XY2 = mvnrnd(muXY', sigma2*Sigma, size_);
    
    X1 = XY1(:, 1:r);       Y1 = XY1(:, (r+1):2*r);
    X2 = XY2(:, 1:r);       Y2 = XY2(:, (r+1):2*r);
    
    %%%%    naive
    naive(w, :) = ( ( mean(Y2, 1) - mean(X2, 1) ) - ...
        ( mean(Y1, 1) - mean(X1, 1) ) );
    
    
    %%%%    BLUE
    alpha = (rho2 - rho3) / (1-rho1);
    beta = r * (rho3 - rho1*rho2)/( (1-rho1)*(1+(r-1)*rho1 ) );
    
    BLUE(w, :) = mean( ( Y2 - alpha*X2 - beta*repmat( mean(X2,2), 1, r) ) - ...
        (Y1 - alpha*X1 - beta*repmat(mean(X1,2), 1, r) ), 1);
    
    
    %%%%    Ttd
    X1_bar = mean(X1, 2);           Y1_bar = mean(Y1, 2);
    X1_vec = reshape(X1, size_*r, 1);   Y1_vec = reshape(Y1, size_*r, 1);
    X1bar_vec = repmat(X1_bar, r, 1);  Y1bar_vec = repmat(Y1_bar, r, 1);
    
    X2_bar = mean(X2, 2);           Y2_bar = mean(Y2, 2);
    X2_vec = reshape(X2, size_*r, 1);   Y2_vec = reshape(Y2, size_*r, 1);
    X2bar_vec = repmat(X2_bar, r, 1);  Y2bar_vec = repmat(Y2_bar, r, 1);
    
    dummy = [repmat( [ones(1, size_), zeros(1, size_*r)], 1, r - 1), ones(1, size_)];
    dummy = reshape( dummy, size_*r, r );
    
    Ttd0 = fitlm([ [dummy;zeros(size_*r, r)],...
        [zeros(size_*r, r);dummy], [X1_vec; X2_vec], [X1bar_vec; X2bar_vec] ],...
        [Y1_vec-X1_vec;Y2_vec-X2_vec], 'Intercept', false);
    %   sorry, sir, here exists rank deficient problem!!!!!
    Ttd(w, :) = table2array( Ttd0.Coefficients(1+r:2*r,1) ) -...
        table2array(Ttd0.Coefficients(1:r, 1));
    
    
    %%%%        MLE, 
    %%%% in matlab coding, ylt
    
    %%%% One-Step
    sigma2_h = sum( diag(cov(X1)) + diag(cov(Y1)) + ...
        diag(cov(X2)) + diag(cov(Y2)) )/(4*r);
    rho1_h = sum(sum(cov(X1) - diag(diag(cov(X1))) + ...
        cov(Y1) - diag(diag(cov(Y1))) + ...
        cov(X2) - diag(diag(cov(X2))) + ...
        cov(Y2) - diag(diag(cov(Y2)))) ) / (4*r*(r-1)*sigma2_h );
    covX1Y1 = cov([X1, Y1]);        covX2Y2 = cov([X2, Y2]);
    rho2_h = sum( diag(covX1Y1(1:r,(r+1):2*r) ) + ...
        diag(covX2Y2(1:r,(r+1):2*r) ) )/(2*r*sigma2_h);
    rho3_h = sum(sum( ...
        covX1Y1 - diag(diag(covX1Y1)) + ...
        covX2Y2 - diag(diag(covX2Y2))   ...
        ) )/( 2*r*(r-1)*sigma2_h );
end