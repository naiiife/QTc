simulation_result=cell(1,1);
n=[10];
r=[10];
p=[2];
Sigma=[400,400,400,400,400,400];
Rho_1=[0.75,0.80,0.85,0.85,0.90,0.90];
Rho_2=[0.85,0.85,0.85,0.85,0.85,0.85];
Rho_3=[0.70,0.80,0.80,0.85,0.85,0.80];
iteration=20000;
for i=1:1
    Rho_1=[0.75,0.80,0.85,0.85,0.90,0.90];
    Rho_2=[0.85,0.85,0.85,0.85,0.85,0.85];
    Rho_3=[0.70,0.80,0.80,0.85,0.85,0.80];
    Mu=200*ones(r(i),1);
    Pi=[0*ones(r(i),1),10*ones(r(i),1)];
    for j=1:6
        error=zeros(3,6);
        Lambda_1=Sigma(j)*(1+(r(i)-1)*Rho_1(j));
        Lambda_2=Sigma(j)*(1-Rho_1(j));
        Lambda_3=Sigma(j)*(Rho_2(j)+(r(i)-1)*Rho_3(j));
        Lambda_4=Sigma(j)*(Rho_2(j)-Rho_3(j));
        Sig=Sigma(j);
        Rho1=Rho_1(j);
        Rho2=Rho_2(j);
        Rho3=Rho_3(j);
        alpha = (Rho2 - Rho3) / (1-Rho1);
        beta = r * (Rho3 - Rho1*Rho2)/( (1-Rho1)*(1+(r-1)*Rho1 ) );
        
        for m=1:iteration
            rand('seed', m)
            data=generate(n(i),r(i),p(i),Mu,Pi,Sig,Rho1,Rho2,Rho3);
%            data=sensitivity(n(i),r(i),p(i),Mu,Pi,Sig,Rho1,Rho2,Rho3);
            [sigma,rho_1,rho_2,rho_3]=MLE(data,n(i),r(i),p(i));    %MLE
            pi=MLE_pi(data,n(i),r(i),p(i),sigma,rho_1,rho_2,rho_3);
            error(1,4)=error(1,4)+sum((pi(:,2)-pi(:,1))-(Pi(:,2)-Pi(:,1)))/r(i);
            error(2,4)=error(2,4)+sum(abs((pi(:,2)-pi(:,1))-(Pi(:,2)-Pi(:,1))))/r(i);
            error(3,4)=error(3,4)+sum(((pi(:,2)-pi(:,1))-(Pi(:,2)-Pi(:,1))).^2)/r(i);
            [sigma,rho_1,rho_2,rho_3]=OLS(data,n(i),r(i),p(i));    %OLS
            pi=MLE_pi(data,n(i),r(i),p(i),sigma,rho_1,rho_2,rho_3);
            error(1,5)=error(1,5)+sum((pi(:,2)-pi(:,1))-(Pi(:,2)-Pi(:,1)))/r(i);
            error(2,5)=error(2,5)+sum(abs((pi(:,2)-pi(:,1))-(Pi(:,2)-Pi(:,1))))/r(i);
            error(3,5)=error(3,5)+sum(((pi(:,2)-pi(:,1))-(Pi(:,2)-Pi(:,1))).^2)/r(i);
            
            X1 = data{1}(:, 1:r);       Y1 = data{1}(:, (r+1):2*r);
            X2 = data{2}(:, 1:r);       Y2 = data{2}(:, (r+1):2*r);
            X1_bar = mean(X1, 2);           Y1_bar = mean(Y1, 2);
            X1_vec = reshape(X1, n*r, 1);   Y1_vec = reshape(Y1, n*r, 1);
            X1bar_vec = repmat(X1_bar, r, 1);  Y1bar_vec = repmat(Y1_bar, r, 1);
            X2_bar = mean(X2, 2);           Y2_bar = mean(Y2, 2);
            X2_vec = reshape(X2, n*r, 1);   Y2_vec = reshape(Y2, n*r, 1);
            X2bar_vec = repmat(X2_bar, r, 1);  Y2bar_vec = repmat(Y2_bar, r, 1);
            
            naive = (( mean(Y2, 1) - mean(X2, 1)) - ( mean(Y1, 1) - mean(X1, 1)))';
            error(1,2)=error(1,2)+sum((naive)-(Pi(:,2)-Pi(:,1)))/r(i);
            error(2,2)=error(2,2)+sum(abs((naive)-(Pi(:,2)-Pi(:,1))))/r(i);
            error(3,2)=error(3,2)+sum(((naive)-(Pi(:,2)-Pi(:,1))).^2)/r(i);
            
            blue = mean( ( Y2 - alpha*X2 - beta*repmat( mean(X2,2), 1, r) ) - ...
                    (Y1 - alpha*X1 - beta*repmat(mean(X1,2), 1, r) ), 1)';
            error(1,1)=error(1,1)+sum((blue)-(Pi(:,2)-Pi(:,1)))/r(i);
            error(2,1)=error(2,1)+sum(abs((blue)-(Pi(:,2)-Pi(:,1))))/r(i);
            error(3,1)=error(3,1)+sum(((blue)-(Pi(:,2)-Pi(:,1))).^2)/r(i);
    
            dummy = [repmat( [ones(1, n), zeros(1, n*r)], 1, r - 1), ones(1, n)];
            dummy = reshape( dummy, n*r, r );
            Ttd0 = fitlm([ [dummy;zeros(n*r, r)],...
                [zeros(n*r, r);dummy], [X1_vec; X2_vec], [X1bar_vec; X2bar_vec] ],...
                [Y1_vec-X1_vec;Y2_vec-X2_vec], 'Intercept', false);
            Ttd = table2array( Ttd0.Coefficients(1+r:2*r,1) ) -...
                table2array(Ttd0.Coefficients(1:r, 1));
            error(1,3)=error(1,3)+sum((Ttd)-(Pi(:,2)-Pi(:,1)))/r(i);
            error(2,3)=error(2,3)+sum(abs((Ttd)-(Pi(:,2)-Pi(:,1))))/r(i);
            error(3,3)=error(3,3)+sum(((Ttd)-(Pi(:,2)-Pi(:,1))).^2)/r(i);
            
            [sigma,rho_1,rho_2,rho_3]=OLS(data,n(i),r(i),p(i));
            alpha_h = (rho_2 - rho_3)/(1 - rho_1);
            beta_h = r(i)*(rho_3 - rho_1*rho_2)/( (1-rho_1)*(1+(r(i)-1)*rho_1) );
            Onestep = mean( (Y2 - alpha_h*X2 - beta_h*reshape( repmat(mean(X2, 2), 1, r(i) ), n(i), r(i) ))-...
                (Y1 - alpha_h*X1 - beta_h*reshape( repmat(mean(X1, 2), 1, r(i) ), n(i), r(i) )), 1)';
            error(1,6)=error(1,6)+sum((Onestep)-(Pi(:,2)-Pi(:,1)))/r(i);
            error(2,6)=error(2,6)+sum(abs((Onestep)-(Pi(:,2)-Pi(:,1))))/r(i);
            error(3,6)=error(3,6)+sum(((Onestep)-(Pi(:,2)-Pi(:,1))).^2)/r(i);    

        end
        result{j}=error/iteration;
    end
    simulation_result{i}=result;
end

simulation_result{1}
RESULT = [simulation_result{1}{1}';
    simulation_result{1}{2}';
    simulation_result{1}{3}';
    simulation_result{1}{4}';
    simulation_result{1}{5}';
    simulation_result{1}{6}'];