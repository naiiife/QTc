function mu = MLE_mu(data,n,r,p)
    mu=zeros(1,r);
    for i=1:p
        A=data{i};
        mu=mu+mean(A(:,1:r))/p;
    end
end

