function [pval, pval_large] = cheng2008_v2( W, sigma_rho, sigma_diag, theta, size_ )
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ: very important
%   �˴���ʾ��ϸ˵��
%   1. size_ : sample size, corresponds to n
%   2. u have to note that, sigma_sum and sigma come from cov(W), which
%   recorded in that article. also, u can check Rk0 in line 14
%   3. I return 2 p-values, pval and another for large samples


    [T, k0] = max(W);   r = length(W);
    sigma_sum = sigma_diag*2;
    sigma_ = sigma_rho*2;
    ak0 = sqrt(size_/abs(2*sigma_sum) ) * (W - W(k0));
    ak0(k0) = [];
    rho_ = sigma_/sigma_sum;     var_ = 1;
    Rk0 = rho_ * ones(r, r) + (var_ - rho_) * eye(r);
    det_ = det(Rk0);            Rk0 = inv(Rk0);
    rho_ = Rk0(2,1);            var_ = Rk0(1,1);
    pd = makedist('Normal', 0, 1);
    
    
    pval_large = cdf(pd, sqrt(size_/sigma_sum) * (T-theta) );
    
    right_ = 1;
    switch (r)
        case 2
            f = @(x, y) x.*x .* ( exp(-0.5 .* handkernel(rho_, var_, x, y) ) ) * power(2*pi, -r/2) / sqrt(det_);
            v1 = integral_8(f, -inf, inf, ak0(1), inf);
            f = @(x, y) x .* ( exp(-0.5 .* handkernel(rho_, var_, x, y) ) ) * power(2*pi, -r/2) / sqrt(det_);
            m1 = integral_8(f, -inf, inf, ak0(1), inf);
            
        case 3
            f = @(x, y, z) x.*x .* ( exp(-0.5 .* handkernel(rho_, var_, x, y, z) ) ) * power(2*pi, -r/2) / sqrt(det_);
            v1 = integral_8(f, -inf, inf, ak0(1), inf, ak0(2), inf);
            f = @(x, y, z) x .* ( exp(-0.5 .* handkernel(rho_, var_, x, y, z) ) ) * power(2*pi, -r/2) / sqrt(det_);
            m1 = integral_8(f, -inf, inf, ak0(1), inf, ak0(2), inf);
            
        case 4
            f = @(x, y, z, x1) x.^2 .* ( exp(-0.5 .* handkernel(rho_, var_, x, y, z, x1) ) ) * power(2*pi, -r/2) / sqrt(det_);
            v1 = integral_8(f, -inf, inf, ak0(1), inf, ak0(2), inf, ak0(3), inf);
            f = @(x, y, z, x1) x .* ( exp(-0.5 .* handkernel(rho_, var_, x, y, z, x1) ) ) * power(2*pi, -r/2) / sqrt(det_);
            m1 = integral_8(f, -inf, inf, ak0(1), inf, ak0(2), inf, ak0(3), inf);
            
        case 5
            f = @(x, y, z, x1, y1) x.^2 .* ( exp(-0.5 .* handkernel(rho_, var_, x, y, z, x1, y1) ) ) * power(2*pi, -r/2) / sqrt(det_);
            v1 = integral_8(f, -inf, inf, ak0(1), inf, ak0(2), inf, ak0(3), inf, ak0(4), inf);
            f = @(x, y, z, x1, y1) x .* ( exp(-0.5 .* handkernel(rho_, var_, x, y, z, x1, y1) ) ) * power(2*pi, -r/2) / sqrt(det_);
            m1 = integral_8(f, -inf, inf, ak0(1), inf, ak0(2), inf, ak0(3), inf, ak0(4), inf);
        otherwise
            right_ = 0;
    end
    if right_ == 1
        pval = cdf(pd, (T - theta*m1)/sqrt( theta*theta*m1*(1-m1) + (sigma_sum)*v1/size_ ));
    else
        pval = -1;
    end
end

