function [result] = si(data,n,r,p)
    result=0;
    m=zeros(1,2*r);
    for i=1:p
        m=m+mean(data{i});
    end
    m=m/p;
    for i=1:p
        M=data{i};
        me=mean(M)-m;
        result=result+sum(me(1:r).*me(1:r));
    end
    result=result*n;
end

