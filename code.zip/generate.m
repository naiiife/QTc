function [data] = generate(n,r,p,mu,pi,sig,rho1,rho2,rho3)
    data=cell(1,p);
    M1=sig*((1-rho1)*eye(r)+rho1*ones(r));
    M2=sig*((rho2-rho3)*eye(r)+rho3*ones(r));
%     M1=zeros(r,r);
%     M2=zeros(r,r);
%     for s=1:r
%         for t=1:r
%             if s==t
%                 M1(s,t)=sig;
%                 M2(s,t)=sig*rho2;
%             else
%                 M1(s,t)=sig*rho1*0.9^(abs(s-t));
%                 M2(s,t)=sig*rho3*0.9^(abs(s-t));
%             end
%         end
%     end
    M=[M1,M2;M2,M1];
    u=zeros(1,2*r);
    for i=1:p
        data{i}=zeros(n,2*r);
        u=[mu;mu+pi(:,i)];
        for j=1:n
            data{i}(j,:)=mvnrnd(u,M);
        end
    end
end

