size_ = 5;                     r = 10;
mu = repmat(200, 1, r);         pi_ = randi([0, 5], 1, r);
a = randi([1, r],1);            pi_(a) = 10;

rho1 = 0.85;    rho2 = 0.85;    rho3 = 0.80;
sigma2 = 400;
disp( ['line 14: ', num2str( int8(1 - rho1 > abs(rho2 - rho3) ) )] )
disp( ['line 14: ', num2str( int8(1 + (r-1)*rho1 > rho2 + (r-1)*rho3 ) ) ] )

for basic_initial = 1:1
    I = eye(r);                 J = ones(r);
    Sigma1 = (1 - rho1)*I + rho1 * J;
    Sigma12 = (rho2 - rho3)*I + rho3 * J;
    Sigma = [ [Sigma1, Sigma12]; [Sigma12', Sigma1] ];
    
    %Omega = Sigma1 - Sigma12' / Sigma1 * Sigma12;
    %muXY = [mu, mu + pi_];
end

it = 1;

for w = 1:it
    rand('seed', 3845 + w);
    XY1 = mvnrnd([mu + pi_, mu]', sigma2*Sigma, size_);
    XY2 = mvnrnd([mu, mu + pi_]', sigma2*Sigma, size_);
    
    X1 = XY1(:, 1:r);       Y1 = XY1(:, r+1:2*r);
    X2 = XY2(:, 1:r);       Y2 = XY2(:, r+1:2*r);
    
    W = (mean(Y1) - mean(X1) + mean(X2) - mean(Y2) )/2;
    [T, k0] = max(W);
    
    sigma2_h = sum( diag(cov(X1)) + diag(cov(Y1)) + ...
        diag(cov(X2)) + diag(cov(Y2)) )/(4*r);
    rho1_h = sum(sum(cov(X1) - diag(diag(cov(X1))) + ...
        cov(Y1) - diag(diag(cov(Y1))) + ...
        cov(X2) - diag(diag(cov(X2))) + ...
        cov(Y2) - diag(diag(cov(Y2)))) ) / (4*r*(r-1)*sigma2_h );
    covX1Y1 = cov([X1, Y1]);        covX2Y2 = cov([X2, Y2]);
    rho2_h = sum( diag(covX1Y1(1:r,(r+1):2*r) ) + ...
        diag(covX2Y2(1:r,(r+1):2*r) ) )/(2*r*sigma2_h);
    rho3_h = sum(sum( ...
        covX1Y1 - diag(diag(covX1Y1)) + ...
        covX2Y2 - diag(diag(covX2Y2))   ...
        ) )/( 2*r*(r-1)*sigma2_h );
    
    disp(['rho_3: ', num2str(rho3_h) ])
    sigma_sum = (1 - rho2_h);
    sigma_rho = (rho1_h - rho3_h);
    
    disp( ['line 42: ', num2str( sigma_sum > sigma_rho) ] )
    %   i am not sure how to estimate. modify here!
end