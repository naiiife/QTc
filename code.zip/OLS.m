function [sigma,p1,p2,p3] = OLS(data,n,r,p)
    Sixx=sixx(data,n,r,p);
    Sixy=sixy(data,n,r,p);
    Siyy=siyy(data,n,r,p);
    Sjxx=sjxx(data,n,r,p);
    Sjxy=sjxy(data,n,r,p);
    Sjyy=sjyy(data,n,r,p);
    clear data;
    sigma=(Sixx+Siyy)/(2*p*r*(n-1));
    p1=(Sjxx-Sixx+Sjyy-Siyy)/(2*p*r*(n-1)*(r-1)*sigma);
    p2=Sixy/((n-1)*r*p*sigma);
    p3=(Sjxy-Sixy)/(p*r*(n-1)*(r-1)*sigma);
end

